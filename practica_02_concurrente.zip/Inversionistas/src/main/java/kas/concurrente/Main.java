package kas.concurrente;

public class Main {
    public static void main(String[] args) {
        System.out.println("Bienvenuti a su practica 2");
    }
}